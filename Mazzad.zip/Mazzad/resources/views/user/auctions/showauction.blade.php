@extends('layouts.admin_app')

@section('content')
        <div>
                <ul>
                        
                <h1>{{ $auctions->car_name }}</h1>
                <li>Price</li>
                <label for="price" class="control-label">{{ $auctions->price }}</label>
                <li>Location</li>
                <label for="location" class="control-label">{{ $auctions->location }}</label>
                        <li>End Date</li>
                <label for="end_date" class="control-label">{{ $auctions->end_date }}</label>
                        <li>Start Bid Amount</li>
                <label for="start_bid_amount" class="control-label">{{ $auctions->start_bid_amount }}</label>
                        <li>Status</li>
                 @if($status)
                <label for="status" class="control-label">{{ $auctions->status ='closed' }}</label>
                @else
                <label for="status" class="control-label">{{ $auctions->status }}</label>
                @endif
                <li> Max Bid</li>
                <label for="status" class="control-label">{{ $maxbid }}</label>
            </br>        
                        @foreach($auctions->car_images as $image)
                        <img src="{{asset('/cars/'.$image->image)}}" alt="Car Image" style="height: 250px; width: 250px;">
                        @endforeach
            </br>
            </br>
                @if(!$status)
                        <a class="btn btn-info btn-fill pull-left" href="{{ route('user-bids', $auctions->id )}}">User Bids</a>
                @endif     

                </ul>
        </br>
        </div>
        
  </br>
        
@endsection