@extends('layouts.admin_app')

@section('content')
    <div class="content">
        <div class="container-fluid">
            <form action="{{ route('add-bid',$auctions->id) }}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
                <input type="hidden" name="auction_id" value="{{ $auctions->id }}">
                <div class="row">
                    <div class="form-group {{ $errors->has('user_bid') ? ' has-error' : '' }}">
                        <label for="user_bid" class="col-md-4 control-label">User Bids</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="User Bids" name="user_bid" type="text" value="{{old('user_bid')}}" required autofocus>
                            @if ($errors->has('user_bid'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('user_bid') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn-fill pull-right">Submit</button>
                </div>
            </form>
        </div>
    </div>
@endsection