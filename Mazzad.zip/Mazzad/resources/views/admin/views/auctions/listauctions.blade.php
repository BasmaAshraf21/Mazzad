@extends('layouts.admin_app')

@section('content')
<h1>List Of All Auctions</h1>

<ul><a href="{{ route('auctions-add')}}">Add A New Auction</a></ul>

   <ul>
 
      @foreach ($listauctions as $auction)

 
        <li>
          
         <a href="{{ route('auctions-show',$auction->id) }}">

         {{ $auction->car_name }}

         </a>
        
        </li>
 
      @endforeach
 </ul>
@endsection
