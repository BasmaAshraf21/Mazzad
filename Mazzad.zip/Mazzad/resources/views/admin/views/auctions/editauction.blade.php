@extends('layouts.admin_app')

@section('content')
    <div class="content">
        <div class="container-fluid">
            <form action="{{ route('auctions-edit',$auctions->id) }}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
                <div class="row">

                    <div class="form-group {{ $errors->has('car_name') ? ' has-error' : '' }}">
                        <label for="car_name" class="col-md-4 control-label">Car Name</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="Car Name" name="car_name" type="text" value="{{$auctions->car_name}}" required autofocus>
                            @if ($errors->has('car_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('car_name') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>

                    <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}">
                        <label for="price" class="col-md-4 control-label">Price</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="Price" name="price" type="text" value="{{$auctions->price}}" required autofocus>
                            @if ($errors->has('price'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group {{ $errors->has('start_bid_amount') ? ' has-error' : '' }}">
                        <label for="start_bid_amount" class="col-md-4 control-label">Start Bid Amount</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="Start Bid Amount" name="start_bid_amount" type="text" value="{{$auctions->start_bid_amount}}" required autofocus>
                            @if ($errors->has('start_bid_amount'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('start_bid_amount') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>

                    <div class="form-group {{ $errors->has('location') ? ' has-error' : '' }}">
                        <label for="location" class="col-md-4 control-label">Location</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="Location" name="location" type="text" value="{{$auctions->location}}" required autofocus>
                            @if ($errors->has('location'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('location') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group {{ $errors->has('end_date') ? ' has-error' : '' }}">
                        <label for="end_date" class="col-md-4 control-label">End Date</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="End Date" name="end_date" type="date" value="{{$auctions->end_date}}" required autofocus>
                            @if ($errors->has('end_date'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('end_date') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group {{ $errors->has('status') ? ' has-error' : '' }}">
                        <label for="status" class="col-md-4 control-label">Status</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="Status" name="status" type="text" value="{{$auctions->status}}" required autofocus>
                            @if ($errors->has('status'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('status') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>
                    
                    <div class="form-group {{ $errors->has('image[]') ? ' has-error' : '' }}">
                        <label for="image[]" class="col-md-4 control-label">Image</label>
                        <div class="col-xs-12">
                            <input class="form-control" multiple name="image[]" type="file" required autofocus>
                            @if ($errors->has('image[]'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('image[]') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn-fill pull-right">edit Auction</button>
                </div>
            </form>
        </div>
    </div>
@endsection