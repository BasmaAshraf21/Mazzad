<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserBid extends Model
{
	protected $fillable = ['user_id','auction_id','user_bid','updated_at','created_at'];
    
    public function auctions()
    {
        return $this->belongsToMany('App\Auction');
    }
}