<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Auction;
use App\CarImage;
use App\UserBid;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }

    public function auctionList()
    {
        $listauctions = Auction::all();
        return view('user.auctions.publicauctionlist', compact('listauctions'));
    }


    public function showAuction(Auction $auctions)
    {
        $enddate = Carbon::parse($auctions['end_date']);    
        $date = Carbon::now();
        if($enddate < $date)
        {
          $status = true;
        }
        else
        {
          $status = false;
        }
        $maxbid = UserBid::where('auction_id',$auctions->id)->max('user_bid');
        return view('user.auctions.showauction',compact('auctions','maxbid','status'));

    }

    public function addBid(Auction $auctions)
    {
        
        return view('user.views.userbid',compact('auctions'));
        

    }


    public function UserBid(Request $request)
    {
        
        $row= $request->all();
        $validatedData = $request->validate([
            'user_id' => 'required',
            'auction_id' => 'required',
            'user_bid' => 'required',
       ]);
    
        UserBid::create(['user_id' => $row['user_id'],'auction_id' => $row['auction_id'],'user_bid'=>$row['user_bid'],'created_at' => Carbon::now()]);

     return redirect('home/public-list'); 
      }
    


}
