<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Szykra\Notifications\Flash;
use App\Auction;
use App\CarImage;
use Carbon\Carbon;
use App\UserBid;

class DashboardController extends Controller
{ 
    public function index()
    {
        if (Auth::user()->isAdmin())
        {
        return view('admin.views.index');
        }
    }

    public function showAuction(Auction $auctions)
    {
        if (Auth::user()->isAdmin())
        {
            $enddate = Carbon::parse($auctions['end_date']);    
            $date = Carbon::now();
            if($enddate < $date)
            {
              $status = true;
            }
            else
            {
              $status = false;
            }
            $maxbid = UserBid::where('auction_id',$auctions->id)->max('user_bid');
            return view('admin.views.auctions.showauction',compact('auctions','status','maxbid'));
        }
    }
    
    public function addAuction(Auction $auctions)
    {  
        if (Auth::user()->isAdmin())
        {
        return view('admin.views.auctions.add', compact('$auctions'));
        }
    }

    public function postAuction(Request $request)
    {  
        if (Auth::user()->isAdmin())
        {
            $validatedData = $request->validate([
            'user_id' => 'required',
            'car_name' => 'required',
            'price' => 'required',
            'location' => 'required',
            'start_bid_amount' => 'required',
            'end_date' => 'required',
            'image' => 'required',
           ]);
            DB::beginTransaction();
            $row = $request->all();

            $data = [

                'user_id' => $row['user_id'],
                'car_name' => $row['car_name'],
                'price' => $row['price'],
                'location' => $row['location'],
                'created_at' => Carbon::now(),
                'start_bid_amount' => $row['start_bid_amount'],
                'end_date' => $row['end_date']
                
            ];
           

            $auction = Auction::create($data);

            $ext = ['jpg', 'png', 'jpeg'];
            foreach ($row['image'] as $image) 
            {
               
                if(in_array($image->getClientOriginalExtension(), $ext)) 
                {
                    $getImage = time() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('cars'), $getImage);

                    $images = [
                        'auction_id' => $auction->id,
                        'image' => $getImage,
                    ];
                    CarImage::create($images);
                } else 
                {
                    DB::rollBack();
                    return redirect()->back();
                }
            }
            
           DB::commit();
            
            return redirect()->route('auctions-list');
        }
    }


    public function listAuctions()
    {
        if (Auth::user()->isAdmin())
        {
           $listauctions = Auction::where('user_id',Auth::user()->id)->get();
          return view('admin.views.auctions.listauctions', compact('listauctions'));
        }
    }

 // Edit Data of Auction
    public function updateAuction(Auction $auctions, CarImage $images)
    {
        if (Auth::user()->isAdmin())
        {
        return view('admin.views.auctions.editauction',compact('auctions', 'images'));
        }
    }


    public function editAuction($id, Request $request)
    { 
        if (Auth::user()->isAdmin())
        {
            $validatedData = $request->validate([
            'user_id' => 'required',
            'car_name' => 'required',
            'price' => 'required',
            'location' => 'required',
            'start_bid_amount' => 'required',
            'end_date' => 'required',
            'status' => 'required',
            'image' => 'required',
           ]);

            $row= $request->all();
        
            Auction::where('id',$id)->update(['car_name'=>$row['car_name'],'price'=>$row['price'],'location'=>$row['location'],'end_date'=>$row['end_date'],'start_bid_amount'=>$row['start_bid_amount'],'status'=>$row['status'],'updated_at' => Carbon::now()]);

            $ext = ['jpg', 'png', 'jpeg'];
            foreach ($row['image'] as $image) 
            {
                
                if(in_array($image->getClientOriginalExtension(), $ext)) 
                {
                    $getImage = time() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('cars'), $getImage);

                    $images = [
                        'image' => $getImage,
                    ];
                    CarImage::where('auction_id',$id)->update($images);
                } else 
                {
                   
                    return redirect()->back();
                }
            }
         return redirect('dashboard'); 

        }
    }
        // Delete Auction
     public function deleteAuction($id)
    {
           if (Auth::user()->isAdmin())
           {
            Auction::where('id', $id)->delete();
            return redirect('/dashboard/auctions');
           }
    }
}
