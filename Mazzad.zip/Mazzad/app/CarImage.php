<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CarImage extends Model
{
    protected $fillable = ['auction_id','image','updated_at','created_at'];

     public function auctions() 
    {
        return $this->belongsTo('App\Auction');
    }
}
