<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
class Auction extends Model
{
    protected $fillable = ['user_id','car_name','price','location','start_bid_amount','end_date','car_image_id','status','updated_at','created_at'];


    public function car_images()
    {
      
     return $this->hasMany('App\CarImage');

    }

    
    public function user_bids()
    {
        return $this->belongsToMany('App\UserBid');
    }



}
