<?php $__env->startSection('content'); ?>
        <div>
        	<ul>
                        
        		<h1><?php echo e($auctions->car_name); ?></h1>
                <li>Price</li>
                <label for="price" class="control-label"><?php echo e($auctions->price); ?></label>
                <li>Location</li>
                <label for="location" class="control-label"><?php echo e($auctions->location); ?></label>
        		<li>End Date</li>
                <label for="end_date" class="control-label"><?php echo e($auctions->end_date); ?></label>
        		<li>Start Bid Amount</li>
                <label for="start_bid_amount" class="control-label"><?php echo e($auctions->start_bid_amount); ?></label>
        		<li>Status</li>
                <?php if($status): ?>
                <label for="status" class="control-label"><?php echo e($auctions->status ='closed'); ?></label>
                <?php else: ?>
                <label for="status" class="control-label"><?php echo e($auctions->status); ?></label>
                <?php endif; ?>
        		<li>Max Bid </li>
                <label for="status" class="control-label"><?php echo e($maxbid); ?></label>
                </br>        
                        <?php $__currentLoopData = $auctions->car_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('/cars/'.$image->image)); ?>" alt="Car Image" style="height: 250px; width: 250px;">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </br>
                </br>
                <div>
                        <a class="btn btn-info btn-fill pull-left" href="<?php echo e(route('auctions-update',$auctions->id)); ?>">Edit</a>
                </div>
                <div>
                        <a class="btn btn-info btn-fill pull-left" href="<?php echo e(route('auctions-delete',$auctions->id)); ?>">Delete</a>
                </div>
        	</ul>

</br>
        </div>
        
  </br>
          
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>