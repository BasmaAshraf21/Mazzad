<?php $__env->startSection('content'); ?>
<h1>List Of All Auctions</h1>


   <ul>
 
      <?php $__currentLoopData = $listauctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 
        <li>
          
         <a href="<?php echo e(route('show-auction',$auction->id)); ?>">

         <?php echo e($auction->car_name); ?>


         </a>
        
        </li>
 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>