<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <form action="<?php echo e(route('add-bid',$auctions->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                <input type="hidden" name="auction_id" value="<?php echo e($auctions->id); ?>">
                <div class="row">
                    <div class="form-group <?php echo e($errors->has('user_bid') ? ' has-error' : ''); ?>">
                        <label for="user_bid" class="col-md-4 control-label">User Bids</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="User Bids" name="user_bid" type="text" value="<?php echo e(old('user_bid')); ?>" required autofocus>
                            <?php if($errors->has('user_bid')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('user_bid')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn-fill pull-right">Submit</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>