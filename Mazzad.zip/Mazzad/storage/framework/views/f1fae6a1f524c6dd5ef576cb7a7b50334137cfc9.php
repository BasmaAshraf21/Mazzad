<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <form action="<?php echo e(route('auctions-post')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                <div class="row">


                    <div class="form-group <?php echo e($errors->has('car_name') ? ' has-error' : ''); ?>">
                        <label for="car_name" class="col-md-4 control-label">Car Name</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="Car Name" name="car_name" type="text" value="<?php echo e(old('car_name')); ?>" required autofocus>
                            <?php if($errors->has('car_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('car_name')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group <?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                        <label for="price" class="col-md-4 control-label">Price</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="Price" name="price" type="text" value="<?php echo e(old('price')); ?>" required autofocus>
                            <?php if($errors->has('price')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('price')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('start_bid_amount') ? ' has-error' : ''); ?>">
                        <label for="start_bid_amount" class="col-md-4 control-label">Start Bid Amount</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="Start Bid Amount" name="start_bid_amount" type="text" value="<?php echo e(old('start_bid_amount')); ?>" required autofocus>
                            <?php if($errors->has('start_bid_amount')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('start_bid_amount')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group <?php echo e($errors->has('location') ? ' has-error' : ''); ?>">
                        <label for="location" class="col-md-4 control-label">Location</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="Location" name="location" type="text" value="<?php echo e(old('location')); ?>" required autofocus>
                            <?php if($errors->has('location')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('location')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('end_date') ? ' has-error' : ''); ?>">
                        <label for="end_date" class="col-md-4 control-label">End Date</label>
                        <div class="col-xs-12">
                            <input class="form-control" placeholder="End Date" name="end_date" type="date" value="<?php echo e(old('end_date')); ?>" required autofocus>
                            <?php if($errors->has('end_date')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('end_date')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('image[]') ? ' has-error' : ''); ?>">
                        <label for="image[]" class="col-md-4 control-label">Image</label>
                        <div class="col-xs-12">
                            <input class="form-control" multiple name="image[]" type="file" required autofocus>
                            <?php if($errors->has('image[]')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image[]')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn-fill pull-right">Add Auction</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>