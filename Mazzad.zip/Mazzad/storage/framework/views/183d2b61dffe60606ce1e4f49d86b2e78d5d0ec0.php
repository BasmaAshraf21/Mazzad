<div class="sidebar-wrapper">
    <div class="logo">
        <a href="/" class="simple-text">
            Mazzad
        </a>
    </div>

    <ul class="nav">
        <?php if(Auth::user()->isAdmin()): ?>
        <li class="active">
            <a href="<?php echo e(route('dashboard')); ?>">
                <i class="pe-7s-graph"></i>
                <p>Dashboard</p>
            </a>
        </li>
        <?php endif; ?>
        <li>
            <a href="<?php echo e(route('home')); ?>">
                <i class="pe-7s-user"></i>
                <p>User Profile</p>
            </a>
        </li>
        <li>
            <?php if(Auth::user()->isAdmin()): ?>
            <a  href="<?php echo e(route('auctions-list')); ?>">
              <i class="pe-7s-note2"></i>
                <p>List Of Auctions</p>
            </a>
            <?php else: ?>
            <a  href="<?php echo e(route('public-list')); ?>">
                <i class="pe-7s-note2"></i>
                <p>List Of Auctions</p>
            </a>
            <?php endif; ?>
        </li>
        <li>
            <a href="typography.html">
                <i class="pe-7s-news-paper"></i>
                <p>Typography</p>
            </a>
        </li>
        <li>
            <a href="icons.html">
                <i class="pe-7s-science"></i>
                <p>Icons</p>
            </a>
        </li>
        <li>
            <a href="maps.html">
                <i class="pe-7s-map-marker"></i>
                <p>Maps</p>
            </a>
        </li>
        <li>
            <a href="notifications.html">
                <i class="pe-7s-bell"></i>
                <p>Notifications</p>
            </a>
        </li>
        <li class="active-pro">
            <a href="upgrade.html">
                <i class="pe-7s-rocket"></i>
                <p>Upgrade to PRO</p>
            </a>
        </li>
    </ul>
</div>