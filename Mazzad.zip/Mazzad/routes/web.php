<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
Route::group(['prefix' => 'home', 'middleware' => 'auth'], function () {
    Route::get('/', 'HomeController@index')->name('home');
    Route::group(['prefix' => 'public-list', 'middleware' => 'auth'], function () {
        Route::get('/', 'HomeController@auctionList')->name('public-list');    
        Route::get('/userbid/{auctions}', 'HomeController@addBid')->name('user-bids');
        Route::post('/addbid/{auctions}', 'HomeController@UserBid')->name('add-bid');
        Route::get('/showauction/{auctions}', 'HomeController@showAuction')->name('show-auction');
    });
});
Route::group(['prefix' => 'dashboard', 'middleware' => 'auth'], function () {
    Route::get('/', 'DashboardController@index')->name('dashboard');
    Route::group(['prefix' => 'auctions', 'middleware' => 'auth'], function () {
        Route::get('/', 'DashboardController@listAuctions')->name('auctions-list');
        Route::get('/add', 'DashboardController@addAuction')->name('auctions-add');
        Route::post('/post', 'DashboardController@postAuction')->name('auctions-post');
        Route::get('/update/{auctions}','DashboardController@updateAuction')->name('auctions-update');
        Route::post('/edit/{auctions}','DashboardController@editAuction')->name('auctions-edit');
        Route::get('/delete/{auctions}', 'DashboardController@deleteAuction')->name('auctions-delete');
        Route::get('/show/{auctions}', 'DashboardController@showAuction')->name('auctions-show');
    });

});